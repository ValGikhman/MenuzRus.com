﻿using System.Web.Mvc;

namespace MenuzRus.Controllers {
    public class ContactController : Controller {
        public ActionResult Index() {
            return View();
        }
    }
}
