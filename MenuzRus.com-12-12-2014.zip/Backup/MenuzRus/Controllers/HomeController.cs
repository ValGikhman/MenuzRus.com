﻿using System.Web.Mvc;

namespace MenuzRus.Controllers {
    public class HomeController : Controller {
        public ActionResult Index() {
            return View();
        }
    }
}
