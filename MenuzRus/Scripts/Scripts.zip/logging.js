$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+588272+'&oi='+41+'&ot=1&&url='+window.location, function(json){})    

});